<?php
class Management_report_model extends CI_Model
{
	
}
