<?php
class Invoice_comp_report_model extends CI_Model
{
	
}
