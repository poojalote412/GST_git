<?php
class Account_report_model extends CI_Model
{
	
}
