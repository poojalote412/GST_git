<!DOCTYPE html>
<html lang="en">



<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>GST Admin</title>
  <!-- base:css -->
  
   <link rel="stylesheet"  href="<?php echo base_url()."vendors/"; ?>select2-bootstrap-theme/select2-bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url()."vendors/"; ?>typicons.font/font/typicons.css">
  <link rel="stylesheet" href="<?php echo base_url()."vendors/";?>css/vendor.bundle.base.css">
  <link rel="stylesheet" href="<?php echo base_url()."vendors/";?>datatables.net-bs4/dataTables.bootstrap4.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo base_url()."css/";?>vertical-layout-light/style.css">
  
  <!-- endinject -->
  <link rel="shortcut icon" href="<?php echo base_url()."images/";?>favicon.png" />
</head>




</body>



</html>