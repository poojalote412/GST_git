

<script src="<?php echo base_url(); ?>vendors/js/vendor.bundle.base.js"></script>
<!-- endinject -->
<!-- Plugin js for this page-->
<!-- End plugin js for this page-->
<!-- inject:js -->
<script src="<?php echo base_url(); ?>js/off-canvas.js"></script>
<script src="<?php echo base_url(); ?>js/hoverable-collapse.js"></script>
<script src="<?php echo base_url(); ?>js/template.js"></script>
<script src="<?php echo base_url(); ?>js/settings.js"></script>
<script src="<?php echo base_url(); ?>js/todolist.js"></script>
<script src="<?php echo base_url(); ?>js/file-upload.js"></script>
<script src="<?php echo base_url(); ?>vendors/datatables.net/jquery.dataTables.js"></script>
<script src="<?php echo base_url(); ?>vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
<script src="<?php echo base_url(); ?>js/data-table.js"></script>
<script src="<?php echo base_url(); ?>vendors/sweetalert/sweetalert.min.js"></script>
<script src="<?php echo base_url(); ?>vendors/jquery.avgrund/jquery.avgrund.min.js"></script>
<script src="<?php echo base_url(); ?>js/alerts.js"></script>
<script src="<?php echo base_url(); ?>js/avgrund.js"></script>

<!--Script for graph-->

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/series-label.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script>