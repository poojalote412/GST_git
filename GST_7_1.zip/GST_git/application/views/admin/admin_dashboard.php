
  
<div class="main-panel">
        <div class="content-wrapper">
           
           Admin Dashboard
            
            
            </div>
       

        </div>
 <?php $this->load->view('customer/footer');?>